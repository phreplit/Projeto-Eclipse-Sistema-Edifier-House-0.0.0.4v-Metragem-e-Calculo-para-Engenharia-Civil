
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 31/10/2024
// Versão Código: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Edifier House - 0.0.0.4v - Metragem e Calculo para Engenharia Civil, com interface grafica e compilacao em ambiente desktop.

package phreplit;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import java.awt.Window.Type;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.Label;
import java.awt.Panel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("unused")
public class EdifierHouse {

	private JFrame frmEdifierHouse;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EdifierHouse window = new EdifierHouse();
					window.frmEdifierHouse.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EdifierHouse() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEdifierHouse = new JFrame();
		frmEdifierHouse.setIconImage(Toolkit.getDefaultToolkit().getImage(EdifierHouse.class.getResource("/phreplit/logo_40px.png")));
		frmEdifierHouse.getContentPane().setBackground(SystemColor.activeCaption);
		frmEdifierHouse.setForeground(SystemColor.activeCaption);
		frmEdifierHouse.setTitle("Sistema - Edifier House - 0.0.0.4v - Metragem e Calculo para Engenharia Civil");
		frmEdifierHouse.setResizable(false);
		frmEdifierHouse.setBounds(100, 100, 1146, 581);
		frmEdifierHouse.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEdifierHouse.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "1. Area de Terreno [Metro Quadrado]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(10, 10, 270, 282);
		frmEdifierHouse.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(10, 56, 181, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 105, 181, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 152, 181, 19);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("Calcular");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mult = Integer.parseInt(textField.getText())*Integer.parseInt(textField_1.getText());
				textField_2.setText(String.valueOf(mult));
			}
		});
		btnNewButton.setBounds(10, 184, 85, 21);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Resetar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				
			}
		});
		btnNewButton_1.setBounds(106, 184, 85, 21);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Digite a Largura.:");
		lblNewLabel.setBounds(10, 33, 181, 13);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Digite o Comprimento.:");
		lblNewLabel_1.setBounds(10, 82, 181, 13);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Resultado - Metro(s) Quad.(s).:");
		lblNewLabel_2.setBounds(10, 129, 250, 13);
		panel.add(lblNewLabel_2);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(SystemColor.activeCaption);
		panel_4.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "5. Area de Muro ou Parede [Metro Quadrado]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_4.setBounds(10, 302, 270, 232);
		frmEdifierHouse.getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_12 = new JLabel("Digite a Altura.:");
		lblNewLabel_12.setBounds(10, 22, 180, 13);
		panel_4.add(lblNewLabel_12);
		
		JLabel lblNewLabel_15 = new JLabel("Digite a Largura.:");
		lblNewLabel_15.setBounds(10, 69, 180, 13);
		panel_4.add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("Resultado - Metro(s) Quad.(s).:");
		lblNewLabel_16.setBounds(10, 111, 180, 13);
		panel_4.add(lblNewLabel_16);
		
		JLabel lblNewLabel_17 = new JLabel("Converter para Qtd. Blocos.:");
		lblNewLabel_17.setBounds(10, 155, 180, 13);
		panel_4.add(lblNewLabel_17);
		
		textField_12 = new JTextField();
		textField_12.setBounds(10, 40, 180, 19);
		panel_4.add(textField_12);
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setBounds(10, 82, 180, 19);
		panel_4.add(textField_13);
		textField_13.setColumns(10);
		
		textField_14 = new JTextField();
		textField_14.setBounds(10, 126, 180, 19);
		panel_4.add(textField_14);
		textField_14.setColumns(10);
		
		textField_15 = new JTextField();
		textField_15.setBounds(10, 170, 180, 19);
		panel_4.add(textField_15);
		textField_15.setColumns(10);
		
		JButton btnNewButton_8 = new JButton("Calcular");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int var4 = 25;
				int mult4 = Integer.parseInt(textField_12.getText())*Integer.parseInt(textField_13.getText());
	            int result4 = mult4 * var4;
	            textField_14.setText(String.valueOf(mult4));
	            textField_15.setText(String.valueOf(result4));
			}
		});
		btnNewButton_8.setBounds(10, 201, 85, 21);
		panel_4.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Resetar");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_12.setText("");
				textField_13.setText("");
				textField_14.setText("");
				textField_15.setText("");
				
			}
		});
		btnNewButton_9.setBounds(105, 201, 85, 21);
		panel_4.add(btnNewButton_9);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(SystemColor.activeCaption);
		panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "6. Area de Casa Edificada [Alvenaria - M\u00B2]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_5.setBounds(290, 302, 264, 232);
		frmEdifierHouse.getContentPane().add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblNewLabel_13 = new JLabel("Digite a Area da Parede M².:");
		lblNewLabel_13.setBounds(10, 22, 175, 13);
		panel_5.add(lblNewLabel_13);
		
		JLabel lblNewLabel_18 = new JLabel("Quantidade de Lados [Parede].:");
		lblNewLabel_18.setBounds(10, 69, 175, 13);
		panel_5.add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("Resultado - Metro(s) Quad.(s).:");
		lblNewLabel_19.setBounds(10, 111, 175, 13);
		panel_5.add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("Converter para Qtd. Blocos.:");
		lblNewLabel_20.setBounds(10, 155, 175, 13);
		panel_5.add(lblNewLabel_20);
		
		textField_16 = new JTextField();
		textField_16.setBounds(10, 40, 175, 19);
		panel_5.add(textField_16);
		textField_16.setColumns(10);
		
		textField_17 = new JTextField();
		textField_17.setBounds(10, 82, 175, 19);
		panel_5.add(textField_17);
		textField_17.setColumns(10);
		
		textField_18 = new JTextField();
		textField_18.setBounds(10, 126, 175, 19);
		panel_5.add(textField_18);
		textField_18.setColumns(10);
		
		textField_19 = new JTextField();
		textField_19.setBounds(10, 170, 175, 19);
		panel_5.add(textField_19);
		textField_19.setColumns(10);
		
		JButton btnNewButton_10 = new JButton("Calcular");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int var5 = 25;
				int mult5 = Integer.parseInt(textField_16.getText())*Integer.parseInt(textField_17.getText());
	            int result5 = mult5 * var5;	             
	            textField_18.setText(String.valueOf(mult5));
	            textField_19.setText(String.valueOf(result5));

			}
		});
		btnNewButton_10.setBounds(10, 201, 85, 21);
		panel_5.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("Resetar");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_16.setText("");
				textField_17.setText("");
				textField_18.setText("");
				textField_19.setText("");
				
			}
		});
		btnNewButton_11.setBounds(105, 201, 85, 21);
		panel_5.add(btnNewButton_11);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(SystemColor.activeCaption);
		panel_6.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "7. Area de Comodo Edificado [Alvenaria - M\u00B2]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_6.setBounds(570, 302, 265, 232);
		frmEdifierHouse.getContentPane().add(panel_6);
		panel_6.setLayout(null);
		
		JLabel lblNewLabel_14 = new JLabel("Digite a Area da Parede M².:");
		lblNewLabel_14.setBounds(10, 22, 180, 13);
		panel_6.add(lblNewLabel_14);
		
		JLabel lblNewLabel_21 = new JLabel("Quantidade de Lados [Parede].:");
		lblNewLabel_21.setBounds(10, 69, 180, 13);
		panel_6.add(lblNewLabel_21);
		
		JLabel lblNewLabel_22 = new JLabel("Resultado - Metro(s) Quad.(s).:");
		lblNewLabel_22.setBounds(10, 111, 180, 13);
		panel_6.add(lblNewLabel_22);
		
		JLabel lblNewLabel_23 = new JLabel("Converter para Qtd. Blocos.:");
		lblNewLabel_23.setBounds(10, 155, 180, 13);
		panel_6.add(lblNewLabel_23);
		
		textField_20 = new JTextField();
		textField_20.setBounds(10, 40, 180, 19);
		panel_6.add(textField_20);
		textField_20.setColumns(10);
		
		textField_21 = new JTextField();
		textField_21.setBounds(10, 82, 180, 19);
		panel_6.add(textField_21);
		textField_21.setColumns(10);
		
		textField_22 = new JTextField();
		textField_22.setBounds(10, 126, 180, 19);
		panel_6.add(textField_22);
		textField_22.setColumns(10);
		
		textField_23 = new JTextField();
		textField_23.setBounds(10, 170, 180, 19);
		panel_6.add(textField_23);
		textField_23.setColumns(10);
		
		JButton btnNewButton_12 = new JButton("Calcular");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int var6 = 25;
				int mult6 = Integer.parseInt(textField_20.getText())*Integer.parseInt(textField_21.getText());
	            int result6 = mult6 * var6;	             
	            textField_22.setText(String.valueOf(mult6));
	            textField_23.setText(String.valueOf(result6));
			}
		});
		btnNewButton_12.setBounds(10, 201, 85, 21);
		panel_6.add(btnNewButton_12);
		
		JButton btnNewButton_13 = new JButton("Resetar");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_20.setText("");
				textField_21.setText("");
				textField_22.setText("");
				textField_23.setText("");
			}
		});
		btnNewButton_13.setBounds(105, 201, 85, 21);
		panel_6.add(btnNewButton_13);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(SystemColor.activeCaption);
		panel_7.setBorder(new TitledBorder(null, "Setup", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_7.setBounds(850, 302, 270, 232);
		frmEdifierHouse.getContentPane().add(panel_7);
		panel_7.setLayout(null);
		
		JButton btnNewButton_14 = new JButton("Info");
		btnNewButton_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(
						null,"Info\n"
			                + "\nPara calcular a Area de Terreno [Metro Quadrado] - Terreno de Tamanho Regular [4 lados iguais] - iremos calcular a largura vezes o comprimento."
			                + "\nPara calcular o Perimetro de Terreno [Metro Corrido] - Terreno de Tamanho Regular [4 lados iguais] - iremos somar todos os lados e obter o metro corrido."
			                + "\nPara calcular a Area de Imovel [Metro Quadrado] - Terreno de Tamanho Regular [4 lados iguais] - iremos calcular a largura vezes o comprimento."
			                + "\nPara calcular o Perimetro de Imovel [Metro Corrido] - Terreno de Tamanho Regular [4 lados iguais] - iremos somar todos os lados e obter o metro corrido."
			                + "\nPara calcular a Area de Muro ou Parede [Metro Quadrado] - Muro ou Parede de Tamanho Regular [4 lados iguais] - iremos calcular a altura vezes a largura."
			                + "\nPara calcular a Area de Casa Edificada [Alvenaria - Metro Quadrado] - Paredes de Tamanho Regular [4 lados iguais] - iremos calcular os metros quadrados de uma parede vezes a quantidade de lados da casa."
			                + "\nPara calcular a Area de Comodo Edificado [Alvenaria - Metro Quadrado] - Parede de Tamanho Regular [4 lados iguais] - iremos calcular os metros quadrados de uma parede vezes a quantidade de lados do comodo."
			                + "\nPara calcular a quantidade de blocos de alvenaria para construir um muro ou parede, iremos calcular os metros quadrados de uma parede vezes 25 que equivale a um metro quadrado com 25 blocos de alvenaria.");

			}
		});
		btnNewButton_14.setBounds(95, 67, 85, 21);
		panel_7.add(btnNewButton_14);
		
		JButton btnNewButton_15 = new JButton("Sobre");
		btnNewButton_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(
						null,"Software:  Edifier House - Metragem e Calculo para Engenharia Civil\n"
						+"\nAuthor: PHNO"
						+"\nData Release: 31/10/2024"
						+"\nVersao Codigo: 0.0.0.4v"
						+"\nReplit: @PHNO, @PHREPLIT"
						+"\nE-mail: phreplit@gmail.com");
			}
		});
		btnNewButton_15.setBounds(95, 98, 85, 21);
		panel_7.add(btnNewButton_15);
		
		JButton btnNewButton_16 = new JButton("Limpar Dados");
		btnNewButton_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				textField_6.setText("");
				textField_7.setText("");
				textField_8.setText("");
				textField_9.setText("");
				textField_10.setText("");
				textField_11.setText("");
				textField_12.setText("");
				textField_13.setText("");
				textField_14.setText("");
				textField_15.setText("");
				textField_16.setText("");
				textField_17.setText("");
				textField_18.setText("");
				textField_19.setText("");
				textField_20.setText("");
				textField_21.setText("");
				textField_22.setText("");
				textField_23.setText("");
			}
		});
		btnNewButton_16.setBounds(81, 129, 112, 21);
		panel_7.add(btnNewButton_16);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.activeCaption);
		panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "2. Perimetro de Terreno [Metro Corrido]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(290, 10, 264, 282);
		frmEdifierHouse.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Digite a Largura.:");
		lblNewLabel_3.setBounds(10, 34, 180, 13);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Digite o Comprimento.:");
		lblNewLabel_4.setBounds(10, 84, 180, 21);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Resultado - Metro(s) Corrido(s).:");
		lblNewLabel_5.setBounds(10, 134, 244, 13);
		panel_1.add(lblNewLabel_5);
		
		textField_3 = new JTextField();
		textField_3.setBounds(10, 55, 180, 19);
		panel_1.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(10, 105, 180, 19);
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(10, 157, 180, 19);
		panel_1.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Calcular");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int var2 = 2;
				int mult2 = Integer.parseInt(textField_3.getText())+Integer.parseInt(textField_4.getText());
                int result2 = mult2 * var2;
                textField_5.setText(String.valueOf(result2));
			}
		});
		btnNewButton_2.setBounds(10, 186, 85, 21);
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Resetar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				
			}
		});
		btnNewButton_3.setBounds(105, 186, 85, 21);
		panel_1.add(btnNewButton_3);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.activeCaption);
		panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3. Area de Imovel [Metro Quadrado]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_2.setBounds(571, 10, 264, 280);
		frmEdifierHouse.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Digite a Largura.:");
		lblNewLabel_6.setBounds(10, 33, 180, 13);
		panel_2.add(lblNewLabel_6);
		
		textField_6 = new JTextField();
		textField_6.setBounds(10, 56, 180, 19);
		panel_2.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(10, 107, 180, 19);
		panel_2.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(10, 160, 180, 19);
		panel_2.add(textField_8);
		textField_8.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Digite o Comprimento.:");
		lblNewLabel_8.setBounds(10, 85, 180, 13);
		panel_2.add(lblNewLabel_8);
		
		JLabel lblNewLabel_10 = new JLabel("Resultado - Metro(s) Quad.(s).:");
		lblNewLabel_10.setBounds(10, 137, 244, 13);
		panel_2.add(lblNewLabel_10);
		
		JButton btnNewButton_4 = new JButton("Calcular");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int mult3 = Integer.parseInt(textField_6.getText())*Integer.parseInt(textField_7.getText());
				textField_8.setText(String.valueOf(mult3));
			}
		});
		btnNewButton_4.setBounds(10, 189, 85, 21);
		panel_2.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Resetar");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_6.setText("");
				textField_7.setText("");
				textField_8.setText("");
				
			}
		});
		btnNewButton_5.setBounds(105, 189, 85, 21);
		panel_2.add(btnNewButton_5);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(SystemColor.activeCaption);
		panel_3.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "4. Perimetro de Imovel [Metro Corrido]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_3.setBounds(850, 10, 270, 282);
		frmEdifierHouse.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		textField_9 = new JTextField();
		textField_9.setBounds(10, 56, 180, 19);
		panel_3.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(10, 107, 180, 19);
		panel_3.add(textField_10);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setBounds(10, 160, 180, 19);
		panel_3.add(textField_11);
		textField_11.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Digite a Largura.:");
		lblNewLabel_7.setBounds(10, 34, 180, 13);
		panel_3.add(lblNewLabel_7);
		
		JLabel lblNewLabel_9 = new JLabel("Digite o Comprimento.:");
		lblNewLabel_9.setBounds(10, 84, 185, 13);
		panel_3.add(lblNewLabel_9);
		
		JLabel lblNewLabel_11 = new JLabel("Resultado - Metro(s) Corrido(s).:");
		lblNewLabel_11.setBounds(10, 134, 250, 13);
		panel_3.add(lblNewLabel_11);
		
		JButton btnNewButton_6 = new JButton("Calcular");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int var3 = 2;
				int mult3 = Integer.parseInt(textField_9.getText())+Integer.parseInt(textField_10.getText());
                int result3 = mult3 * var3;
                textField_11.setText(String.valueOf(result3));
			}
		});
		btnNewButton_6.setBounds(10, 187, 85, 21);
		panel_3.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Resetar");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_9.setText("");
				textField_10.setText("");
				textField_11.setText("");
				
			}
		});
		btnNewButton_7.setBounds(105, 187, 85, 21);
		panel_3.add(btnNewButton_7);
	}
}
